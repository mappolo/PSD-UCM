#!/bin/bash

./run -u Cmdenv -f omnetpp.ini -c discoC > salidaDiscoC_8Blades.txt
./run -u Cmdenv -f omnetpp.ini -c discoD > salidaDiscoD_8Blades.txt 
./run -u Cmdenv -f omnetpp.ini -c discoE > salidaDiscoE_8Blades.txt
