#!/bin/bash


cd Scen_16Blades_1Core
./run -u Cmdenv > salidaScen_16Blades_1Core.txt
cd ..

cd Scen_16Blades_2Core
./run -u Cmdenv > salidaScen_16Blades_2Core.txt
cd ..

cd Scen_16Blades_4Core
./run -u Cmdenv > salidaScen_16Blades_4Core.txt
cd ..

cd Scen_16Blades_8Core
./run -u Cmdenv > salidaScen_16Blades_8Core.txt
cd ..
