#!/bin/bash

./run -u Cmdenv -f omnetpp.ini -c discoC > salidaDiscoC_16Blades.txt
./run -u Cmdenv -f omnetpp.ini -c discoD > salidaDiscoD_16Blades.txt 
./run -u Cmdenv -f omnetpp.ini -c discoE > salidaDiscoE_16Blades.txt
