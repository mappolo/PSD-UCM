#!/bin/bash

./run -u Cmdenv -f omnetpp.ini -c discoC > salidaDiscoC_4Blades.txt
./run -u Cmdenv -f omnetpp.ini -c discoD > salidaDiscoD_4Blades.txt 
./run -u Cmdenv -f omnetpp.ini -c discoE > salidaDiscoE_4Blades.txt
