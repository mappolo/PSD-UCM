#!/bin/bash

./run -u Cmdenv -f omnetpp_100M.ini -c discoA > salidaDiscoA_100M.txt
./run -u Cmdenv -f omnetpp_100M.ini -c discoB > salidaDiscoB_100M.txt 
./run -u Cmdenv -f omnetpp_100M.ini -c discoC > salidaDiscoC_100M.txt
./run -u Cmdenv -f omnetpp_1G.ini -c discoA > salidaDiscoA_1G.txt
./run -u Cmdenv -f omnetpp_1G.ini -c discoB > salidaDiscoB_1G.txt 
./run -u Cmdenv -f omnetpp_1G.ini -c discoC > salidaDiscoC_1G.txt 
./run -u Cmdenv -f omnetpp_10G.ini -c discoA > salidaDiscoA_10G.txt
./run -u Cmdenv -f omnetpp_10G.ini -c discoB > salidaDiscoB_10G.txt 
./run -u Cmdenv -f omnetpp_10G.ini -c discoC > salidaDiscoC_10G.txt 
