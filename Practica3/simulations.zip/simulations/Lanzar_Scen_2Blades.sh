#!/bin/bash


cd Scen_2Blades_1Core
./run -u Cmdenv > salidaScen_2Blades_1Core.txt
cd ..

cd Scen_2Blades_2Core
./run -u Cmdenv > salidaScen_2Blades_2Core.txt
cd ..

cd Scen_2Blades_4Core
./run -u Cmdenv > salidaScen_2Blades_4Core.txt
cd ..

cd Scen_2Blades_8Core
./run -u Cmdenv > salidaScen_2Blades_8Core.txt
cd ..
