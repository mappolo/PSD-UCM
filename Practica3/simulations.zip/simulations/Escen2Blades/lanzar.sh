#!/bin/bash

./run -u Cmdenv -f omnetpp.ini -c discoC > salidaDiscoC_2Blades.txt
./run -u Cmdenv -f omnetpp.ini -c discoD > salidaDiscoD_2Blades.txt 
./run -u Cmdenv -f omnetpp.ini -c discoE > salidaDiscoE_2Blades.txt
